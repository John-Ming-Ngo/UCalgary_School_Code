#! /bin/sh

java -cp .:game/IOStuff/audio/JLayer.jar game/MarketSim
