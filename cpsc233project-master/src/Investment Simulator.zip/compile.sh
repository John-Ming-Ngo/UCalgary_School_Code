#! /bin/sh

javac -cp .:game/IOStuff/audio/JLayer.jar game/MarketSim.java

