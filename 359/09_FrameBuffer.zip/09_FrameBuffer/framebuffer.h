void initFrameBuffer();
void displayFrameBuffer();
