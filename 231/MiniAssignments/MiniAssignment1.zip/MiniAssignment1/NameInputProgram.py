print("I shall be asking for your name soon.")
inputName = input("What is your name? ")
print(inputName, "is a nice name! Here's fifteen points.")
